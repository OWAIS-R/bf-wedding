# Bilal Khan & Falak Izhar — Wedding Invitation Website

A single-page, static wedding invitation site (Rasme Manjha · Baraat · Walima, Kanpur, November 2026).
No build step — plain HTML/CSS/JS.

## Structure

```
index.html          the whole site
images/             invitation cards (.jpg previews, .png downloads)
invitations.zip     all invitation cards, for download
logo.png, og-image.png, favicon*, icon-192.png, apple-touch-icon.png
```

## Deploy with GitHub Pages

1. Push this repo to GitHub.
2. **Settings → Pages → Build and deployment**: Source = *Deploy from a branch*, Branch = `main`, folder = `/ (root)`.
3. The site goes live at `https://<username>.github.io/<repo>/`.

### After it's live

In `index.html`, change the `og:image` meta tag to the full URL so WhatsApp/Facebook link previews work:

```html
<meta property="og:image" content="https://<username>.github.io/<repo>/og-image.png">
```

## Local preview

```
python3 -m http.server 8000
```
then open http://localhost:8000
